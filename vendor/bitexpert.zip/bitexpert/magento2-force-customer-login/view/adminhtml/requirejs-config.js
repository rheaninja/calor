/**
 * Copyright © 2016 bitExpert AG. All rights reserved.
 * See LICENSE file for license details.
 */

var config = {
    map: {
        '*': {}
    },
    "shim": {}
};